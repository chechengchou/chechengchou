"""
 Sessions store user info state after login
"""