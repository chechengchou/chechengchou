def cmd_listener():
    print('Welcome to course registration system. Type help to view all command we support')

    pass


if __name__ == '__main__':
    cmd_listener()
