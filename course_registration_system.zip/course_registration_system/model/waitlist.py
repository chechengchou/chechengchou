class WaitList:

    @property
    def id(self):
        return self._id

    @property
    def course_id(self):
        return self._course_id

    @property
    def student_id(self):
        return self._student_id


    def __int__(self):
        self._id = None
        self._course_id = None
        self._student_id = None
        return

    def __init__(self, id, course_id, _student_id):
        self._id = id
        self._course_id = course_id
        self._student_id = _student_id
