class Course:

    @property
    def id(self):
        return self._id

    @property
    def course_name(self):
        return self._course_name

    @property
    def max_limit(self):
        return self._max_limit

    @property
    def start_date(self):
        return self._start_date

    def __int__(self):
        self.__init__(None, None, None, None)
        return

    def __init__(self, id, course_name, max_limit, start_date):
        self._id = id
        self._course_name = course_name
        self._max_limit = max_limit
        self._start_date = start_date
