from db.accessor_mysql.mysql_accessor import MySqlAccessor

config = {
    'constructor': {
        'mysql': MySqlAccessor,
        'sqlite': MySqlAccessor
    },
    'username': {
        'mysql': 'root',
        'mongo': 'root'
    },
    'password': {
        'mysql': '123',
        'mongo': '123'
    },
    'host': {
        'mysql': '123',
        'mongo': '123'
    },
    'database': {
        'mysql': '123',
        'mongo': '123'
    },
}

DB_ENGINE = MySqlAccessor()


def GLOBAL_SET_DB_ENGINE(engine):
    global DB_ENGINE
    constructFunc = config['constructor'][engine]
    DB_ENGINE = constructFunc(
        config['username'][engine],
        config['password'][engine],
        config['host'][engine],
        config['database'][engine],
    )
