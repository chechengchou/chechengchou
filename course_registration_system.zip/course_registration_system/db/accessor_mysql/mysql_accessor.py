import mysql.connector

from db.db_accessor import DBAccessor


class MySqlAccessor(DBAccessor):

    def __init__(self) -> None:
        super().__init__()
        self._db = mysql.connector.connect(
            # do connection
        )

    def select(self):
        super().select()

    def delete_by_id(self, row_id):
        super().delete_by_id(row_id)

    def insert(self, row):
        super().insert(row)

