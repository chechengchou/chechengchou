class DBAccessor:
    def select(self):
        return

    def delete_by_id(self, row_id):
        return

    def insert(self, row):
        return
