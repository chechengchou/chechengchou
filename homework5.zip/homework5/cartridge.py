from abstract_cartridge import AbstractCartridge


class Cartridge(AbstractCartridge):
    def __init__(self,s,num_pages):
        print("Cartridge is " + s + "\n")
