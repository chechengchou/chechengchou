from printer import Printer
'''
The problem I found and the solution:
1. It violates dependency inversion principle (one of SOLID principle). Solution: I created an AbstractCartridge class which contains an abstract constructor
and then inherit from ABC
2. In printer.py, there's only one parameter in the Cartridge(), but it should pass two parameter to Cartridge class.
(Because the constructor in the Cartridge class contains two parameters) Solution: I declare a variable num_page and set the value as a random
number from 1 to max. Thus, it will pass two parameters to Cartridge class and fix the issue.
3. There's no prepare function call. Thus, I call it before print() to the whole program more complete.
'''


def main():
    print("Printer is warming up...please be patient!\n")
    printer = Printer()
    printer.prepare()
    print("All I want to do is print...so all I'm doing is printing...")
    printer.print()


if __name__ == '__main__':
    main()

