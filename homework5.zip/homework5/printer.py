import sys

from cartridge import Cartridge
import random

class Printer:
    def prepare(self):
        print("Printer is preparing to print\n")
        name = "X543-44"
        num_pages = random.randint(0,sys.maxsize)
        cartridge = Cartridge(name,num_pages)

    def print(self):
        print("Printer is printing\n")

