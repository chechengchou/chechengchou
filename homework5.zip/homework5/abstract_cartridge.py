from abc import ABC, abstractmethod


class AbstractCartridge(ABC):
    @abstractmethod
    def __init__(self,s,num_pages):
        pass